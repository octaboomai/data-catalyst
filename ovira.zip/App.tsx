import React, { useState, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import ReactMarkdown from 'react-markdown';
import { Message, Sender, AppMode, AppTab, ModeConfig } from './types';
import { geminiService } from './services/gemini';
import { Background } from './components/Background';
import { ChatBubble } from './components/ChatBubble';
import { InputArea } from './components/InputArea';
import { 
  Baby, Flower2, HeartHandshake, ChevronRight, Sparkles, Calendar, 
  MessageSquarePlus, X, Home, Activity, MessageCircle, User, 
  AlertTriangle, Phone, CheckCircle2, Droplets, Utensils,
  Ruler, Weight, Info, Stethoscope, ChevronDown, Settings, LogOut, WifiOff, Save,
  Sun, Moon, Coffee, Sunrise, Dumbbell, Zap, Wind, Navigation, Users, Map as MapIcon, Timer,
  Check, Ban, Sparkle
} from 'lucide-react';

const MODES: ModeConfig[] = [
  { 
    id: AppMode.PREGNANCY, 
    label: 'Pregnancy', 
    icon: 'Flower2', 
    description: 'Guidance',
    color: 'bg-rose-500' 
  },
  { 
    id: AppMode.POSTPARTUM, 
    label: 'Postpartum', 
    icon: 'HeartHandshake', 
    description: 'Recovery',
    color: 'bg-violet-500' 
  },
  { 
    id: AppMode.NEWBORN, 
    label: 'Newborn', 
    icon: 'Baby', 
    description: 'Care',
    color: 'bg-sky-500' 
  },
];

const SUGGESTED_PROMPTS: Record<AppMode, string[]> = {
  [AppMode.PREGNANCY]: [
    "🥭 Is Papaya safe?",
    "🥛 Benefits of Kesar milk",
    "🧘‍♀️ Iron-rich Indian veg diet",
    "🏥 Hospital bag checklist"
  ],
  [AppMode.POSTPARTUM]: [
    "🍲 Veg diet for breastfeeding",
    "🤕 C-section stitch care",
    "💆‍♀️ Is 'Japa' massage safe?",
    "😣 Hair fall remedies"
  ],
  [AppMode.NEWBORN]: [
    "🧴 Best oil for Malish",
    "💉 Vaccination Schedule",
    "👶 Colic home remedies",
    "💤 Baby sleeping pattern"
  ]
};

const INITIAL_MESSAGE: Message = {
  id: 'init',
  text: "**Namaste! Welcome to Ovira.** 🙏\n\nI am your companion. Ask me about Indian nutrition, pregnancy myths, or baby care.\n\n*Note: I am an AI. For medical emergencies, dial 102/108.*",
  sender: Sender.AI,
  timestamp: new Date()
};

interface NutritionPlan {
  time: string;
  icon: any;
  focus: string;
  consume: string[];
  avoid: string[];
  tip: string;
}

const NUTRITION_GUIDANCE: Record<string, NutritionPlan> = {
  'Morning': {
    time: 'Morning (5 AM - 11 AM)',
    icon: Sunrise,
    focus: 'Brain Health & Energy',
    consume: [
      'Soaked Almonds & Walnuts (Omega-3)',
      'Lemon & Ginger water (Nausea relief)',
      'Whole grain Poha or Oats (Iron & Energy)'
    ],
    avoid: [
      'High-sugar processed cereals',
      'Empty stomach caffeine (Heartburn risk)',
      'Very oily parathas'
    ],
    tip: 'Starting with protein and healthy fats helps stabilize blood sugar for the whole day.'
  },
  'Afternoon': {
    time: 'Afternoon (11 AM - 4 PM)',
    icon: Sun,
    focus: 'Iron & Calcium Absorption',
    consume: [
      'Lentils (Dal) with Lemon (Vitamin C for Iron)',
      'Curd/Buttermilk (Calcium & Probiotics)',
      'Dark leafy greens like Palak (Minerals)'
    ],
    avoid: [
      'Drinking Tea/Coffee with lunch (Blocks Iron)',
      'Unwashed raw salads (Infection risk)',
      'Extremely spicy red chili'
    ],
    tip: 'Always pair your iron-rich lentils with citrus to maximize mineral absorption.'
  },
  'Evening': {
    time: 'Evening (4 PM - 8 PM)',
    icon: Coffee,
    focus: 'Micronutrients & Hydration',
    consume: [
      'Roasted Makhana (High Calcium snack)',
      'Seasonal fruits (Vitamin C & Fiber)',
      'Coconut water (Electrolytes)'
    ],
    avoid: [
      'Deep-fried samosas/pakoras',
      'Carbonated sugary drinks',
      'Heavy tea/coffee late in the day'
    ],
    tip: 'Makhana is a superfood for pregnancy; it’s low in fat and high in minerals needed for baby’s bones.'
  },
  'Night': {
    time: 'Night (8 PM - 5 AM)',
    icon: Moon,
    focus: 'Immunity & Recovery',
    consume: [
      'Warm Turmeric Milk (Haldi Doodh)',
      'Light protein like Paneer or Tofu',
      'Fiber-rich steamed vegetables'
    ],
    avoid: [
      'Raw Papaya or Pineapple',
      'Heavy red meat or beans (Gas/Bloating)',
      'Late-night heavy sweets'
    ],
    tip: 'Turmeric milk acts as a natural immunity booster and helps you sleep better.'
  }
};

const PRENATAL_EXERCISES = {
  1: [
    { name: "Pelvic Tilts", duration: "5-10 mins", icon: Activity, desc: "Gently strengthens abdominal muscles and relieves back pain.", safety: "Keep breathing normally, don't hold your breath." },
    { name: "Ankle Rotations", duration: "2 mins", icon: Wind, desc: "Improves blood circulation and reduces swelling in feet.", safety: "Can be done while sitting or lying down." },
    { name: "Brisk Walking", duration: "20 mins", icon: Navigation, desc: "Best low-impact cardio for overall fitness.", safety: "Wear supportive shoes and stay hydrated." }
  ],
  2: [
    { name: "Cat-Cow Stretch", duration: "5 mins", icon: Baby, desc: "Relieves spine tension and improves flexibility.", safety: "Move slowly; avoid overstretching your belly." },
    { name: "Butterfly Stretch", duration: "5 mins", icon: Zap, desc: "Opens hips and prepares the body for labor.", safety: "Keep your back straight, sit on a cushion if needed." },
    { name: "Side-Lying Leg Lifts", duration: "10 reps each", icon: Activity, desc: "Strengthens hips and outer thighs.", safety: "Use your arm to support your head comfortably." }
  ],
  3: [
    { name: "Deep Squats (Malasana)", duration: "2-3 mins", icon: Zap, desc: "Traditional Indian pose to open the pelvis and strengthen legs.", safety: "Use a wall for balance or a low stool for support." },
    { name: "Wall Push-ups", duration: "10-15 reps", icon: Activity, desc: "Safe way to maintain upper body strength without lying flat.", safety: "Stand far enough to feel resistance but not strain." },
    { name: "Seated Neck Rolls", duration: "3 mins", icon: Wind, desc: "Relieves tension from carrying extra baby weight.", safety: "Move very slowly to avoid dizziness." }
  ]
};

// Path for Walking Journey SVG (Winding road)
const WALK_PATH_D = "M 10 70 C 40 70, 60 20, 100 20 C 140 20, 160 80, 200 80 C 240 80, 260 30, 290 30";

// --- Helpers for Calculation ---
const calculatePregnancyWeek = (dueDateStr: string): number => {
  if (!dueDateStr) return 4;
  const due = new Date(dueDateStr);
  const today = new Date();
  const diffTime = due.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const daysPassed = 280 - diffDays;
  const weeks = Math.floor(daysPassed / 7);
  return Math.max(4, Math.min(42, weeks));
};

const getFruitForWeek = (week: number): string => {
  if (week < 12) return 'Lime';
  if (week < 16) return 'Apple';
  if (week < 20) return 'Banana';
  if (week < 24) return 'Pomegranate';
  if (week < 28) return 'Kesar Mango';
  if (week < 32) return 'Coconut';
  if (week < 36) return 'Papaya';
  return 'Watermelon';
};

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.HOME);
  const [messages, setMessages] = useState<Message[]>([INITIAL_MESSAGE]);
  const [currentMode, setCurrentMode] = useState<AppMode>(AppMode.PREGNANCY);
  const [isLoading, setIsLoading] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showVitalsModal, setShowVitalsModal] = useState(false);
  const [showExerciseModal, setShowExerciseModal] = useState(false);
  const [showWalkModal, setShowWalkModal] = useState(false);
  const [isWalking, setIsWalking] = useState(false);
  const [walkProgress, setWalkProgress] = useState(0); // 0 to 100
  const [nutritionPlan, setNutritionPlan] = useState<NutritionPlan>(NUTRITION_GUIDANCE.Morning);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);

  // Home Dashboard State
  const [checklist, setChecklist] = useState({
    vitamins: false,
    water: false,
    walk: false,
    fetalKick: false
  });

  // Profile State
  const [userProfile, setUserProfile] = useState({
    name: "Priya Sharma",
    dueDate: "2025-05-15", 
    doctorName: "Dr. Anjali Gupta",
    liteMode: false
  });

  // Vitals State
  const [vitals, setVitals] = useState({
    bpSys: 120,
    bpDia: 80,
    hb: 11.2,
    heartRate: 78,
    weight: 68
  });

  const [tempVitals, setTempVitals] = useState({ ...vitals });

  // Derived State
  const currentWeek = calculatePregnancyWeek(userProfile.dueDate);
  const currentTrimester = Math.ceil(currentWeek / 13) as 1 | 2 | 3;
  const currentFruit = getFruitForWeek(currentWeek);

  const getRiskStatus = () => {
    if (vitals.bpSys >= 140 || vitals.bpDia >= 90 || vitals.hb < 10) {
      return { level: 'High Risk', color: 'bg-red-500', text: 'text-red-700', bg: 'bg-red-50', icon: AlertTriangle };
    }
    if (vitals.bpSys >= 130 || vitals.bpDia >= 85 || vitals.hb < 11) {
      return { level: 'Medium Risk', color: 'bg-orange-500', text: 'text-orange-700', bg: 'bg-orange-50', icon: AlertTriangle };
    }
    return { level: 'Low Risk', color: 'bg-teal-500', text: 'text-teal-700', bg: 'bg-teal-50', icon: Activity };
  };

  const risk = getRiskStatus();

  useEffect(() => {
    geminiService.initChat(currentMode);
    const updateNutrition = () => {
      const hour = new Date().getHours();
      let period = 'Morning';
      if (hour >= 11 && hour < 16) period = 'Afternoon';
      else if (hour >= 16 && hour < 20) period = 'Evening';
      else if (hour >= 20 || hour < 5) period = 'Night';
      setNutritionPlan(NUTRITION_GUIDANCE[period]);
    };
    updateNutrition();
    const interval = setInterval(updateNutrition, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let interval: any;
    if (isWalking && walkProgress < 100) {
      interval = setInterval(() => {
        setWalkProgress(prev => Math.min(prev + 0.5, 100));
      }, 500); 
    } else if (walkProgress >= 100) {
      setIsWalking(false);
      setChecklist(prev => ({...prev, walk: true}));
    }
    return () => clearInterval(interval);
  }, [isWalking, walkProgress]);

  // Calculate coordinates on the SVG path for the avatar
  const getPointAtLength = (progress: number) => {
    if (!pathRef.current) return { x: 10, y: 70 };
    const totalLength = pathRef.current.getTotalLength();
    const point = pathRef.current.getPointAtLength((progress / 100) * totalLength);
    return { x: point.x, y: point.y };
  };

  const avatarPos = getPointAtLength(walkProgress);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (activeTab === AppTab.CHAT) {
      scrollToBottom();
    }
  }, [messages, isLoading, activeTab]);

  const handleModeSwitch = (mode: AppMode) => {
    if (mode === currentMode) return;
    setCurrentMode(mode);
    geminiService.switchMode(mode);
    setActiveTab(AppTab.CHAT);
    
    const modeConfig = MODES.find(m => m.id === mode);
    const switchMsg: Message = {
      id: uuidv4(),
      text: `_Context updated: **${modeConfig?.label}**. How can I help?_`,
      sender: Sender.AI,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, switchMsg]);
  };

  const handleSendMessage = async (text: string) => {
    setActiveTab(AppTab.CHAT);
    const userMsg: Message = { id: uuidv4(), text, sender: Sender.USER, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const aiMsgId = uuidv4();
      const aiMsgPlaceholder: Message = { id: aiMsgId, text: '', sender: Sender.AI, timestamp: new Date() };
      setMessages(prev => [...prev, aiMsgPlaceholder]);

      let fullResponse = '';
      const stream = geminiService.sendMessageStream(text);

      for await (const chunk of stream) {
        fullResponse += chunk;
        setMessages(prev => prev.map(msg => msg.id === aiMsgId ? { ...msg, text: fullResponse } : msg));
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveVitals = () => {
    setVitals(tempVitals);
    setShowVitalsModal(false);
  };

  const startWalkJourney = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(() => {
        setIsWalking(true);
        setShowWalkModal(true);
      });
    } else {
      setIsWalking(true);
      setShowWalkModal(true);
    }
  };

  const renderHome = () => (
    <div className="pb-24 pt-4 px-4 space-y-6 animate-fade-in">
      {/* Greeting Card */}
      <div 
        onClick={() => setActiveTab(AppTab.TRACKER)}
        className="bg-gradient-to-br from-rose-500 to-rose-600 rounded-3xl p-6 text-white shadow-soft relative overflow-hidden cursor-pointer active:scale-98 transition-transform"
      >
        <div className="relative z-10">
          <p className="opacity-90 text-sm font-medium mb-1">Namaste, {userProfile.name.split(' ')[0]}</p>
          <h2 className="text-2xl font-bold mb-4">Week {currentWeek}</h2>
          <div className="flex items-center gap-4 bg-white/20 backdrop-blur-sm p-3 rounded-xl border border-white/30">
            <div className="text-3xl">🥭</div>
            <div>
              <p className="text-xs opacity-90">Baby Size</p>
              <p className="font-semibold text-lg">{currentFruit}</p>
            </div>
            <div className="ml-auto">
              <ChevronRight className="text-white/70" size={20} />
            </div>
          </div>
        </div>
        <div className="absolute right-[-20px] top-[-20px] opacity-10">
          <Baby size={180} />
        </div>
      </div>

      {/* Grid Features */}
      <div className="grid grid-cols-2 gap-4">
        <div 
          onClick={() => setActiveTab(AppTab.VITALS)}
          className="bg-white rounded-2xl p-4 shadow-card border border-rose-100 flex flex-col justify-between cursor-pointer active:scale-98 transition-transform"
        >
          <div>
            <h3 className="font-bold text-slate-800 text-sm">Health Status</h3>
            <p className="text-[10px] text-slate-500 mt-1">Based on log</p>
          </div>
          <div className={`mt-3 flex items-center gap-2 ${risk.bg} px-3 py-1.5 rounded-full self-start`}>
            <div className={`w-2 h-2 ${risk.color} rounded-full animate-pulse`}></div>
            <span className={`text-xs font-bold ${risk.text}`}>{risk.level}</span>
          </div>
        </div>

        <div 
          onClick={() => setShowExerciseModal(true)}
          className="bg-violet-50 rounded-2xl p-4 shadow-card border border-violet-100 flex flex-col justify-between cursor-pointer active:scale-98 transition-transform"
        >
          <div className="flex justify-between items-start">
             <h3 className="font-bold text-slate-800 text-sm">Safe Exercises</h3>
             <Dumbbell size={16} className="text-violet-400" />
          </div>
          <div className="mt-2 text-[10px] text-violet-600 font-bold uppercase tracking-wider">Trimester {currentTrimester}</div>
          <p className="text-[10px] text-slate-500">3 recommended today</p>
        </div>
      </div>

      {/* Detailed Nutrition Section */}
      <div className="bg-white rounded-2xl p-5 shadow-card border border-peach-100 overflow-hidden relative">
        <div className="flex items-center justify-between mb-4">
           <div className="flex items-center gap-2">
              <div className="p-2 bg-peach-50 text-peach-600 rounded-lg">
                 {React.createElement(nutritionPlan.icon, { size: 20 })}
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-sm">{nutritionPlan.time}</h3>
                <p className="text-[10px] text-peach-600 font-bold uppercase tracking-widest">{nutritionPlan.focus}</p>
              </div>
           </div>
           <div className="text-[10px] text-slate-400 font-medium">Daily Guide</div>
        </div>

        <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-teal-600 mb-1">
                    <Check size={14} strokeWidth={3} />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Consume</span>
                </div>
                {nutritionPlan.consume.map((item, i) => (
                    <div key={i} className="flex gap-2 items-start">
                        <div className="w-1 h-1 rounded-full bg-teal-400 mt-1.5 shrink-0"></div>
                        <p className="text-[11px] text-slate-600 leading-tight">{item}</p>
                    </div>
                ))}
            </div>

            <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-rose-500 mb-1">
                    <Ban size={14} strokeWidth={3} />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Avoid</span>
                </div>
                {nutritionPlan.avoid.map((item, i) => (
                    <div key={i} className="flex gap-2 items-start">
                        <div className="w-1 h-1 rounded-full bg-rose-300 mt-1.5 shrink-0"></div>
                        <p className="text-[11px] text-slate-600 leading-tight">{item}</p>
                    </div>
                ))}
            </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-50 flex items-start gap-3">
            <Info size={16} className="text-peach-400 shrink-0 mt-0.5" />
            <p className="text-xs text-slate-500 italic leading-snug">"{nutritionPlan.tip}"</p>
        </div>
      </div>

      {/* Walking Journey Territory Explorer - ENHANCED VISUALS */}
      <div className="bg-white rounded-3xl p-5 shadow-card border border-teal-100 relative overflow-hidden group">
        <div className="flex justify-between items-center mb-5 relative z-10">
            <div>
                <h3 className="font-bold text-slate-800 flex items-center gap-2 text-base">
                    <Navigation size={18} className="text-teal-500" /> Walking Journey
                </h3>
                <p className="text-[10px] text-slate-500">Territory: Green & Growing</p>
            </div>
            <div className="bg-teal-50 text-teal-600 px-3 py-1.5 rounded-full text-[10px] font-bold flex items-center gap-2 shadow-sm">
                <Users size={12} /> 12 Nearby
            </div>
        </div>

        {/* Map Journey Visualization - Path and Avatar */}
        <div className="h-32 bg-slate-50/50 rounded-2xl relative mb-4 overflow-hidden border border-slate-100/50">
             {/* Background Grid */}
             <div className="absolute inset-0 opacity-[0.1]" style={{ backgroundImage: 'linear-gradient(to right, #2dd4bf 1px, transparent 1px), linear-gradient(to bottom, #2dd4bf 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
             
             {/* Winding Path SVG */}
             <svg className="absolute inset-0 w-full h-full" viewBox="0 0 300 100" fill="none">
                {/* Base Grey Path */}
                <path d={WALK_PATH_D} stroke="#e2e8f0" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
                
                {/* Progress Path with Glow */}
                <path 
                  ref={pathRef}
                  d={WALK_PATH_D} 
                  stroke="#2dd4bf" 
                  strokeWidth="6" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                  strokeDasharray="1000"
                  strokeDashoffset={1000 - (10 * walkProgress)}
                  className="transition-all duration-500 ease-linear shadow-lg"
                  filter="drop-shadow(0 0 4px rgba(45, 212, 191, 0.5))"
                />
                
                {/* Community Overlaps (Icons on path) */}
                <circle cx="160" cy="80" r="4" fill="#fb7185" className="animate-pulse" />
                <circle cx="240" cy="80" r="4" fill="#fb7185" className="animate-pulse delay-500" />
             </svg>
             
             {/* Avatar Pointer with Walking Bobbing Animation */}
             <div 
                className={`absolute transition-all duration-500 ease-linear z-20 ${isWalking ? 'animate-bounce-slow' : ''}`}
                style={{ 
                    left: `${(avatarPos.x / 300) * 100}%`, 
                    top: `${(avatarPos.y / 100) * 100}%`,
                    transform: 'translate(-50%, -100%)'
                }}
             >
                <div className="relative">
                   <div className="bg-white p-1.5 rounded-full shadow-lg border-2 border-teal-400">
                      <Baby size={22} className="text-teal-500" />
                   </div>
                   {/* Walking Trail Effect */}
                   {isWalking && (
                     <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
                        <div className="w-1 h-1 bg-teal-400/50 rounded-full animate-ping"></div>
                        <div className="w-1 h-1 bg-teal-400/50 rounded-full animate-ping delay-75"></div>
                     </div>
                   )}
                </div>
             </div>

             {/* Overlap Popups */}
             <div className="absolute left-[55%] top-[70%] group-hover:opacity-100 transition-opacity">
                <div className="bg-white text-[8px] font-bold px-2 py-1 rounded-full border border-rose-100 shadow-sm whitespace-nowrap flex items-center gap-1 animate-float">
                  <Sparkle size={8} className="text-rose-400" /> Walk with Meera
                </div>
             </div>
        </div>

        <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
               <div className="flex justify-between text-[10px] font-bold text-teal-600 mb-1">
                   <span>Goal: 20m</span>
                   <span>{walkProgress}%</span>
               </div>
               <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                   <div className="h-full bg-teal-500 transition-all duration-300" style={{ width: `${walkProgress}%` }}></div>
               </div>
            </div>
            <button 
                onClick={startWalkJourney}
                className={`px-6 py-2.5 rounded-2xl font-bold text-xs shadow-lg transition-all active:scale-95 flex items-center gap-2 ${isWalking ? 'bg-amber-100 text-amber-700 shadow-amber-100' : 'bg-teal-500 text-white shadow-teal-200'}`}
            >
                {isWalking ? <Timer size={14} className="animate-spin-slow" /> : <MapIcon size={14} />}
                {isWalking ? "Pause" : "Start"}
            </button>
        </div>
      </div>

      {/* Daily Checklist */}
      <div className="bg-white rounded-2xl p-5 shadow-card border border-rose-100">
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
          <CheckCircle2 size={18} className="text-rose-500" /> Daily Goals
        </h3>
        <div className="space-y-3">
          {[
            { id: 'vitamins', label: 'Take Iron/Calcium supplements', icon: '💊' },
            { id: 'water', label: 'Drink 8 glasses of water', icon: '💧' },
            { id: 'walk', label: '20 min gentle walk', icon: '🚶‍♀️' },
            { id: 'fetalKick', label: 'Count fetal kicks', icon: '👣' }
          ].map((item) => (
            <div 
              key={item.id}
              onClick={() => setChecklist(prev => ({...prev, [item.id]: !prev[item.id as keyof typeof checklist]}))}
              className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100 active:scale-98 transition-transform cursor-pointer"
            >
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${checklist[item.id as keyof typeof checklist] ? 'bg-rose-500 border-rose-500' : 'border-slate-300'}`}>
                {checklist[item.id as keyof typeof checklist] && <CheckCircle2 size={14} className="text-white" />}
              </div>
              <span className={`text-sm ${checklist[item.id as keyof typeof checklist] ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderVitals = () => (
    <div className="pb-24 pt-4 px-4 space-y-6 animate-fade-in">
      <div className="flex justify-between items-center px-2">
         <h2 className="text-xl font-bold text-slate-800">Vitals Log</h2>
         <span className={`text-xs font-bold px-2 py-1 rounded ${risk.bg} ${risk.text}`}>{risk.level}</span>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-rose-100 shadow-card">
          <div className="text-rose-400 mb-2"><Activity size={20} /></div>
          <p className="text-xs text-slate-500">Blood Pressure</p>
          <p className="text-xl font-bold text-slate-800">{vitals.bpSys}/{vitals.bpDia}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-rose-100 shadow-card">
          <div className="text-rose-400 mb-2"><Droplets size={20} /></div>
          <p className="text-xs text-slate-500">Hemoglobin</p>
          <p className="text-xl font-bold text-slate-800">{vitals.hb}</p>
        </div>
      </div>
      <div className="bg-rose-50 border border-rose-100 rounded-xl p-4 text-center">
        <button onClick={() => {setTempVitals({...vitals}); setShowVitalsModal(true);}} className="mt-3 text-xs font-bold bg-white text-rose-600 px-6 py-3 rounded-full shadow-sm">+ Update Vitals</button>
      </div>
    </div>
  );

  const renderTracker = () => (
    <div className="pb-24 pt-4 px-4 space-y-6 animate-fade-in">
        <h2 className="text-xl font-bold text-slate-800">Growth Tracker</h2>
        <div className="bg-white rounded-3xl p-6 shadow-card border border-rose-100 text-center relative overflow-hidden">
            <h3 className="text-4xl font-bold text-rose-500 mb-1">Week {currentWeek}</h3>
            <div className="w-32 h-32 bg-orange-100 rounded-full mx-auto flex items-center justify-center mb-4"><span className="text-6xl">🥭</span></div>
            <h4 className="text-xl font-bold text-slate-800">{currentFruit}</h4>
        </div>
    </div>
  );

  const renderProfile = () => (
      <div className="pb-24 pt-4 px-4 space-y-6 animate-fade-in">
        <h2 className="text-xl font-bold text-slate-800 px-2">Profile</h2>
        <div className="bg-white rounded-2xl p-6 shadow-card border border-rose-100">
            <h3 className="font-bold text-lg text-slate-800 mb-1">{userProfile.name}</h3>
            <p className="text-xs text-slate-500">Trimester {currentTrimester}</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-card border border-rose-100 space-y-4">
            <div><label className="block text-xs font-semibold text-slate-500 mb-1">Name</label><input type="text" value={userProfile.name} onChange={(e) => setUserProfile({...userProfile, name: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm" /></div>
            <div><label className="block text-xs font-semibold text-slate-500 mb-1">Due Date</label><input type="date" value={userProfile.dueDate} onChange={(e) => setUserProfile({...userProfile, dueDate: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm" /></div>
        </div>
      </div>
  );

  return (
    <div className="relative min-h-screen font-sans bg-rose-50/30 text-slate-800 pb-0">
      <Background />
      <header className="fixed top-0 left-0 right-0 z-20 bg-white/80 backdrop-blur-xl border-b border-rose-100 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-3 flex justify-between items-center">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-500 flex items-center justify-center text-white shadow-md"><Flower2 size={18} /></div>
                <div><h1 className="text-lg font-bold text-slate-800 leading-none">Ovira</h1><span className="text-[10px] font-semibold text-rose-500 uppercase tracking-widest">Maternal</span></div>
            </div>
             <button onClick={() => setShowFeedback(true)} className="text-xs font-medium text-rose-600 bg-rose-50 px-3 py-1.5 rounded-full border border-rose-100">Feedback</button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto pt-20 md:pt-24 min-h-screen">
        {activeTab === AppTab.HOME && renderHome()}
        {activeTab === AppTab.VITALS && renderVitals()}
        {activeTab === AppTab.TRACKER && renderTracker()}
        {activeTab === AppTab.PROFILE && renderProfile()}
        {activeTab === AppTab.CHAT && (
            <div className="flex flex-col h-full pb-36 px-4 pt-4">
                {messages.map((msg) => <ChatBubble key={msg.id} message={msg} />)}
                {isLoading && <div className="flex gap-2 items-center text-slate-400 text-xs ml-4 mb-4"><span className="w-2 h-2 bg-rose-400 rounded-full animate-bounce"></span><span className="w-2 h-2 bg-rose-400 rounded-full animate-bounce delay-100"></span><span className="w-2 h-2 bg-rose-400 rounded-full animate-bounce delay-200"></span></div>}
                <div ref={messagesEndRef} />
            </div>
        )}
      </main>

      {activeTab === AppTab.CHAT && <InputArea onSend={handleSendMessage} disabled={isLoading} />}
      <button className="fixed bottom-20 right-4 z-40 bg-red-500 text-white rounded-full p-3 shadow-lg flex items-center gap-2 pr-5"><Phone size={20} className="animate-bounce" /><span className="font-bold text-sm">102/108</span></button>

      <div className="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-rose-100 pb-safe">
        <div className="max-w-3xl mx-auto flex justify-around items-center h-16">
          <button onClick={() => setActiveTab(AppTab.HOME)} className={`flex flex-col items-center gap-1 w-full h-full justify-center ${activeTab === AppTab.HOME ? 'text-rose-500' : 'text-slate-400'}`}><Home size={22} /><span className="text-[10px]">Home</span></button>
          <button onClick={() => setActiveTab(AppTab.VITALS)} className={`flex flex-col items-center gap-1 w-full h-full justify-center ${activeTab === AppTab.VITALS ? 'text-rose-500' : 'text-slate-400'}`}><Activity size={22} /><span className="text-[10px]">Vitals</span></button>
          <button onClick={() => setActiveTab(AppTab.CHAT)} className="relative -top-5 bg-rose-500 text-white p-4 rounded-full shadow-lg"><MessageCircle size={26} fill="white" /></button>
          <button onClick={() => setActiveTab(AppTab.TRACKER)} className={`flex flex-col items-center gap-1 w-full h-full justify-center ${activeTab === AppTab.TRACKER ? 'text-rose-500' : 'text-slate-400'}`}><Calendar size={22} /><span className="text-[10px]">Tracker</span></button>
          <button onClick={() => setActiveTab(AppTab.PROFILE)} className={`flex flex-col items-center gap-1 w-full h-full justify-center ${activeTab === AppTab.PROFILE ? 'text-rose-500' : 'text-slate-400'}`}><User size={22} /><span className="text-[10px]">Profile</span></button>
        </div>
      </div>

      {/* Modals (Simplified for context) */}
      {showExerciseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
           <div className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl relative max-h-[80vh] overflow-y-auto">
              <button onClick={() => setShowExerciseModal(false)} className="absolute top-4 right-4 text-slate-400"><X size={20} /></button>
              <h3 className="text-xl font-bold text-slate-800 mb-6">Trimester {currentTrimester} Exercises</h3>
              <div className="space-y-4">
                  {PRENATAL_EXERCISES[currentTrimester].map((ex, i) => (
                    <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                        <h4 className="font-bold text-slate-800">{ex.name} • <span className="text-xs text-slate-400 font-normal">{ex.duration}</span></h4>
                        <p className="text-sm text-slate-600 mt-1">{ex.desc}</p>
                    </div>
                  ))}
              </div>
           </div>
        </div>
      )}

      {showWalkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-fade-in">
            <div className="bg-white w-full max-w-sm rounded-3xl p-8 shadow-2xl text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-teal-500"></div>
                <div className="w-20 h-20 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-6"><Navigation size={40} className="text-teal-600 animate-bounce" /></div>
                <h3 className="text-2xl font-bold text-slate-800 mb-2">Journey Active!</h3>
                <p className="text-sm text-slate-500 mb-8">You are exploring your territory with {checklist.walk ? 'community encouragement' : '12 others'}!</p>
                <div className="space-y-6">
                    <div>
                        <div className="flex justify-between text-xs font-bold text-teal-600 mb-2"><span>Progress</span><span>{walkProgress.toFixed(0)}%</span></div>
                        <div className="h-3 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-teal-500 transition-all duration-300" style={{ width: `${walkProgress}%` }}></div></div>
                    </div>
                </div>
                <button onClick={() => {setIsWalking(false); setShowWalkModal(false);}} className="mt-8 w-full py-3 text-slate-500 font-bold">Return to Dashboard</button>
            </div>
        </div>
      )}

      {showVitalsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
           <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl">
              <h3 className="text-lg font-bold text-slate-800 mb-4">Log Vitals</h3>
              <div className="space-y-4">
                  <div><label className="text-xs text-slate-500 block mb-1">BP Sys</label><input type="number" value={tempVitals.bpSys} onChange={e => setTempVitals({...tempVitals, bpSys: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 p-2 rounded-lg" /></div>
              </div>
              <div className="flex justify-end gap-3 mt-6"><button onClick={() => setShowVitalsModal(false)} className="text-sm text-slate-500">Cancel</button><button onClick={saveVitals} className="text-sm font-bold bg-rose-500 text-white px-6 py-2 rounded-full">Save</button></div>
           </div>
        </div>
      )}
    </div>
  );
}
