import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Message, Sender } from '../types';
import { Sparkles, User } from 'lucide-react';

interface ChatBubbleProps {
  message: Message;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.sender === Sender.USER;

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'} animate-slide-up`}>
      <div className={`flex max-w-[90%] md:max-w-[80%] gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        
        {/* Avatar */}
        <div className={`
          w-9 h-9 rounded-full flex items-center justify-center shrink-0 border shadow-sm
          ${isUser 
            ? 'bg-slate-100 border-slate-200' 
            : 'bg-gradient-to-br from-rose-400 to-rose-500 border-rose-200 text-white'}
        `}>
          {isUser ? (
            <User size={16} className="text-slate-500" />
          ) : (
            <Sparkles size={16} className="text-white" />
          )}
        </div>

        {/* Bubble */}
        <div className={`
          flex flex-col p-4 rounded-2xl shadow-card
          ${isUser 
            ? 'bg-rose-500 text-white rounded-tr-sm' 
            : 'bg-white border border-rose-100 text-slate-700 rounded-tl-sm'}
        `}>
          <div className={`prose prose-sm max-w-none ${isUser ? 'prose-invert' : 'prose-rose'}`}>
            <ReactMarkdown
              components={{
                ul: ({node, ...props}) => <ul className="list-disc pl-4 my-2 space-y-1" {...props} />,
                li: ({node, ...props}) => <li className="" {...props} />,
                strong: ({node, ...props}) => <strong className={`font-bold ${isUser ? 'text-white' : 'text-rose-600'}`} {...props} />,
                h3: ({node, ...props}) => <h3 className={`text-sm font-bold uppercase tracking-wide mt-3 mb-1 ${isUser ? 'text-rose-100' : 'text-rose-500'}`} {...props} />,
              }}
            >
              {message.text}
            </ReactMarkdown>
          </div>
          
          {/* Timestamp */}
          <div className={`flex items-center gap-2 mt-1 self-end text-[10px] ${isUser ? 'text-rose-100/70' : 'text-slate-400'}`}>
            <span>
              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};