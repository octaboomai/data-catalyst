import React from 'react';

export const Background: React.FC = () => {
  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden -z-10 bg-rose-50/50">
      {/* Soft, nurturing orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-rose-200/40 rounded-full blur-[100px] animate-pulse-slow"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-peach-100/60 rounded-full blur-[100px] animate-pulse-slow" style={{animationDelay: '2s'}}></div>
      <div className="absolute top-[40%] left-[30%] w-[40%] h-[40%] bg-white/60 rounded-full blur-[80px]"></div>
      
      {/* Subtle Texture Pattern (Dots) */}
      <div className="absolute inset-0 opacity-[0.4]" style={{
        backgroundImage: 'radial-gradient(#fb7185 0.5px, transparent 0.5px)',
        backgroundSize: '24px 24px'
      }}></div>
    </div>
  );
};