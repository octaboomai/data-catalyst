import React, { useState, useRef, useEffect } from 'react';
import { Send, Baby, Mic } from 'lucide-react';

interface InputAreaProps {
  onSend: (text: string) => void;
  disabled: boolean;
}

export const InputArea: React.FC<InputAreaProps> = ({ onSend, disabled }) => {
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (text.trim() && !disabled) {
      onSend(text.trim());
      setText('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [text]);

  return (
    <div className="fixed bottom-16 left-0 right-0 p-3 bg-white/80 backdrop-blur-md border-t border-rose-100 z-10">
      <div className="max-w-3xl mx-auto relative">
        <form 
          onSubmit={handleSubmit}
          className="relative flex items-end gap-2 p-2 rounded-3xl bg-white border border-rose-200 shadow-soft transition-all focus-within:ring-2 focus-within:ring-rose-200"
        >
          <div className="pl-2 pb-3 text-rose-400">
            <Baby size={22} />
          </div>
          
          <textarea
            ref={textareaRef}
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask me anything (English or Hinglish)..."
            className="flex-1 bg-transparent border-none text-slate-700 placeholder-slate-400 focus:ring-0 resize-none py-3 max-h-32 text-base scrollbar-hide leading-relaxed"
            disabled={disabled}
          />

           {/* Mic Icon (Visual Only for MVP) */}
           <button type="button" className="pb-3 pr-1 text-slate-400 hover:text-rose-500 transition-colors">
              <Mic size={20} />
           </button>

          <button
            type="submit"
            disabled={!text.trim() || disabled}
            className={`
              p-3 rounded-full mb-0.5 transition-all duration-200
              ${text.trim() && !disabled 
                ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-200' 
                : 'bg-slate-100 text-slate-300 cursor-not-allowed'}
            `}
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};