export enum Sender {
  USER = 'user',
  AI = 'ai'
}

export interface Message {
  id: string;
  text: string;
  sender: Sender;
  timestamp: Date;
}

export enum AppMode {
  PREGNANCY = 'PREGNANCY', // Weekly updates, symptoms
  POSTPARTUM = 'POSTPARTUM', // Recovery, mental health
  NEWBORN = 'NEWBORN' // Feeding, sleep, care
}

export enum AppTab {
  HOME = 'HOME',
  CHAT = 'CHAT',
  VITALS = 'VITALS',
  TRACKER = 'TRACKER',
  PROFILE = 'PROFILE'
}

export interface ModeConfig {
  id: AppMode;
  label: string;
  icon: string; // Using string names for Lucide icons
  description: string;
  color: string;
}