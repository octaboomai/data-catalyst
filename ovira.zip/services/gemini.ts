import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { AppMode } from "../types";

const API_KEY = process.env.API_KEY || '';

// Indian Context Disclaimer
const BASE_DISCLAIMER = "\n\nIMPORTANT: I am an AI companion, not a doctor. This information is for educational purposes. Always consult your Gynecologist or Pediatrician for medical advice. In an emergency in India, dial 102 (Ambulance) or 108.";

const SYSTEM_INSTRUCTIONS: Record<AppMode, string> = {
  [AppMode.PREGNANCY]: `You are a caring and knowledgeable pregnancy companion for an Indian user.
  - **Context:** Understand Indian cultural nuances, joint family dynamics, and common myths (e.g., eclipse superstitions, saffron milk).
  - **Diet:** Suggest Indian home-cooked meals (Roti, Dal, Sabzi, Curd). Focus on vegetarian sources of protein (Paneer, Chana, Lentils) unless the user asks for non-veg.
  - **Safety:** Be firm about avoiding raw papaya and pineapple if asked (common Indian concerns), explaining the medical nuance gently.
  - **Language:** You understand Hinglish (Hindi-English mix). Reply in clear English but you can use warm Indian terms like "Beta" or "Didi" if the user sets that tone, otherwise keep it professional.
  - **Emergency:** Refer to 102/108.
  ${BASE_DISCLAIMER}`,
  
  [AppMode.POSTPARTUM]: `You are a supportive postpartum guide respecting Indian traditions like the 40-day confinement ('Japa' or 'Sawa Mahina').
  - **Recovery:** Support traditional recovery foods (Panjiri, Gond laddoo, Ajwain water) while ensuring nutritional balance.
  - **Mental Health:** There is stigma around Postpartum Depression in some Indian circles. Be extra supportive, validating, and private.
  - **Hygiene:** Advice on C-section/stitch care suitable for Indian climates (humidity/heat).
  ${BASE_DISCLAIMER}`,
  
  [AppMode.NEWBORN]: `You are an expert on newborn care in an Indian context.
  - **Massage:** Acknowledge the tradition of 'Malish' (oil massage). Advise on safe techniques and safe oils (Coconut/Almond) vs avoiding strong mustard oil on sensitive skin.
  - **Vaccines:** Refer to the IAP (Indian Academy of Pediatrics) immunization schedule.
  - **Feeding:** 'Fed is Best', but support breastfeeding heavily. Suggest Indian galactagogues (Jeera water, Methi seeds) for milk supply.
  - **Home Remedies:** Be cautious with 'Dadi ke nuskhe' (Home remedies). Allow harmless ones (hing for gas) but strictly forbid dangerous ones (honey before 1 year, kajal in eyes).
  ${BASE_DISCLAIMER}`
};

class GeminiService {
  private ai: GoogleGenAI;
  private chat: Chat | null = null;
  private currentMode: AppMode = AppMode.PREGNANCY;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: API_KEY });
  }

  public initChat(mode: AppMode) {
    this.currentMode = mode;
    this.chat = this.ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTIONS[mode],
        temperature: 0.6, // Balanced creativity and accuracy
      },
    });
  }

  public async *sendMessageStream(message: string): AsyncGenerator<string, void, unknown> {
    if (!this.chat) {
      this.initChat(this.currentMode);
    }

    if (!this.chat) throw new Error("Chat initialization failed");

    try {
      const result = await this.chat.sendMessageStream({ message });
      
      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        if (c.text) {
          yield c.text;
        }
      }
    } catch (error) {
      console.error("Gemini Error:", error);
      yield "Namaste! I'm having a little trouble connecting right now. Please check your internet or try again in a moment. 🙏";
    }
  }

  public switchMode(mode: AppMode) {
    this.initChat(mode);
  }
}

export const geminiService = new GeminiService();